<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Jadwal extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MSudi');
    }

    public function index()
    {
        $data['DataDaftarJadwal'] = $this->MSudi->GetJadwal();

        $this->load->view('VDaftarJadwal', $data);
    }
}
