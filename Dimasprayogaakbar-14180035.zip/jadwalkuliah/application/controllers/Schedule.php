<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Schedule extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('MSudi');
    }

    public function index()
    {
        if ($this->session->userdata('Login')) {
            $data['content'] = 'VBlank';
            $this->load->view('VBackend', $data);
        } else {
            redirect(site_url('Login'));
        }
    }


//  Awal Data Dosen -------------------------------------------------------------------------------------------------------------
    public function DataDosen()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_dosen = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_dosen', 'kd_dosen', $kd_dosen)->row();
            $data['detail']['kd_dosen'] = $tampil->kd_dosen;
            $data['detail']['nama_dosen'] = $tampil->nama_dosen;
            $data['content'] = 'VFormUpdateDosen';
        } else {
            $data['DataDosen'] = $this->MSudi->GetData('tbl_dosen');
            $data['content'] = 'VDosen';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddDosen()
    {
        $data['content'] = 'VFormAddDosen';
        $this->load->view('VBackend', $data);
    }

    public function AddDataDosen()
    {
        $add['kd_dosen'] = $this->input->post('kd_dosen');
        $add['nama_dosen'] = $this->input->post('nama_dosen');
        $this->MSudi->AddData('tbl_dosen', $add);
        redirect(site_url('Schedule/DataDosen'));
    }

    public function UpdateDataDosen()
    {
        $kd_dosen = $this->input->post('kd_dosen');
        $update['nama_dosen'] = $this->input->post('nama_dosen');
        $this->MSudi->UpdateData('tbl_dosen', 'kd_dosen', $kd_dosen, $update);
        redirect(site_url('Schedule/DataDosen'));
    }

    public function DeleteDataDosen()
    {
        $kd_dosen = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_dosen', 'kd_dosen', $kd_dosen);
        redirect(site_url('Schedule/DataDosen'));
    }

    //  Akhir Data Dosen -------------------------------------------------------------------------------------------------------------



 //  AWal Data Maktul -------------------------------------------------------------------------------------------------------------
    public function DataMatkul()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_matkul = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_matakuliah', 'kd_matkul', $kd_matkul)->row();
            $data['detail']['kd_matkul'] = $tampil->kd_matkul;
            $data['detail']['nama_matkul'] = $tampil->nama_matkul;
            $data['detail']['waktu'] = $tampil->waktu;
            $data['detail']['semester'] = $tampil->semester;
            $data['content'] = 'VFormUpdateMatkul';
        } else {
            $data['DataMatkul'] = $this->MSudi->GetData('tbl_matakuliah');
            $data['content'] = 'VMatkul';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddMatkul()
    {
        $data['content'] = 'VFormAddMatkul';
        $this->load->view('VBackend', $data);
    }

    public function AddDataMatkul()
    {
        $add['kd_matkul'] = $this->input->post('kd_matkul');
        $add['nama_matkul'] = $this->input->post('nama_matkul');
        $add['waktu'] = $this->input->post('waktu');
        $add['semester'] = $this->input->post('semester');
        $this->MSudi->AddData('tbl_matakuliah', $add);
        redirect(site_url('Schedule/DataMatkul'));
    }

    public function UpdateDataMatkul()
    {
        $kd_matkul = $this->input->post('kd_matkul');
        $update['nama_matkul'] = $this->input->post('nama_matkul');
        $update['waktu'] = $this->input->post('waktu');
        $update['semester'] = $this->input->post('semester');
        $this->MSudi->UpdateData('tbl_matakuliah', 'kd_matkul', $kd_matkul, $update);
        redirect(site_url('Schedule/DataMatkul'));
    }

    public function DeleteDataMatkul()
    {
        $kd_matkul = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_matakuliah', 'kd_matkul', $kd_matkul);
        redirect(site_url('Schedule/DataMatkul'));
    }

    //  Akhir Data Matkul -------------------------------------------------------------------------------------------------------------

    

    //  Awal Data Jurusan -------------------------------------------------------------------------------------------------------------
    public function DataJurusan()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_jurusan = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_jurusan', 'kd_jurusan', $kd_jurusan)->row();
            $data['detail']['kd_jurusan'] = $tampil->kd_jurusan;
            $data['detail']['nama_jurusan'] = $tampil->nama_jurusan;
            $data['content'] = 'VFormUpdateJurusan';
        } else {
            $data['DataJurusan'] = $this->MSudi->GetData('tbl_jurusan');
            $data['content'] = 'VJurusan';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddJurusan()
    {
        $data['content'] = 'VFormAddJurusan';
        $this->load->view('VBackend', $data);
    }

    public function AddDataJurusan()
    {
        $add['kd_jurusan'] = $this->input->post('kd_jurusan');
        $add['nama_jurusan'] = $this->input->post('nama_jurusan');
        $this->MSudi->AddData('tbl_jurusan', $add);
        redirect(site_url('Schedule/DataJurusan'));
    }

    public function UpdateDataJurusan()
    {
        $kd_jurusan = $this->input->post('kd_jurusan');
        $update['nama_jurusan'] = $this->input->post('nama_jurusan');
        $this->MSudi->UpdateData('tbl_jurusan', 'kd_jurusan', $kd_jurusan, $update);
        redirect(site_url('Schedule/DataJurusan'));
    }

    public function DeleteDataJurusan()
    {
        $kd_jurusan = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_jurusan', 'kd_jurusan', $kd_jurusan);
        redirect(site_url('Schedule/DataJurusan'));
    }

    //  Akhir Data Jurusan -------------------------------------------------------------------------------------------------------------

    //  Awal Data Hari -------------------------------------------------------------------------------------------------------------
    public function DataHari()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_hari = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_hari', 'kd_hari', $kd_hari)->row();
            $data['detail']['kd_hari'] = $tampil->kd_hari;
            $data['detail']['nama_hari'] = $tampil->nama_hari;
            $data['content'] = 'VFormUpdateHari';
        } else {
            $data['DataHari'] = $this->MSudi->GetData('tbl_hari');
            $data['content'] = 'VHari';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddHari()
    {
        $data['content'] = 'VFormAddHari';
        $this->load->view('VBackend', $data);
    }

    public function AddDataHari()
    {
        $add['kd_hari'] = $this->input->post('kd_hari');
        $add['nama_hari'] = $this->input->post('nama_hari');
        $this->MSudi->AddData('tbl_hari', $add);
        redirect(site_url('Schedule/DataHari'));
    }

    public function UpdateDataHari()
    {
        $kd_hari = $this->input->post('kd_hari');
        $update['nama_hari'] = $this->input->post('nama_hari');
        $this->MSudi->UpdateData('tbl_hari', 'kd_hari', $kd_hari, $update);
        redirect(site_url('Schedule/DataHari'));
    }

    public function DeleteDataHari()
    {
        $kd_hari = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_hari', 'kd_hari', $kd_hari);
        redirect(site_url('Schedule/DataHari'));
    }

    //  Akhir Data Hari -------------------------------------------------------------------------------------------------------------

    //  Awal Data Ruangan -------------------------------------------------------------------------------------------------------------
    public function DataRuangan()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_ruangan = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_ruangan', 'kd_ruangan', $kd_ruangan)->row();
            $data['detail']['kd_ruangan'] = $tampil->kd_ruangan;
            $data['detail']['nama_ruangan'] = $tampil->nama_ruangan;
            $data['content'] = 'VFormUpdateRuangan';
        } else {
            $data['DataRuangan'] = $this->MSudi->GetData('tbl_ruangan');
            $data['content'] = 'VRuangan';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddRuangan()
    {
        $data['content'] = 'VFormAddRuangan';
        $this->load->view('VBackend', $data);
    }

    public function AddDataRuangan()
    {
        $add['kd_ruangan'] = $this->input->post('kd_ruangan');
        $add['nama_ruangan'] = $this->input->post('nama_ruangan');
        $this->MSudi->AddData('tbl_ruangan', $add);
        redirect(site_url('Schedule/DataRuangan'));
    }

    public function UpdateDataRuangan()
    {
        $kd_ruangan = $this->input->post('kd_ruangan');
        $update['nama_ruangan'] = $this->input->post('nama_ruangan');
        $this->MSudi->UpdateData('tbl_ruangan', 'kd_ruangan', $kd_ruangan, $update);
        redirect(site_url('Schedule/DataRuangan'));
    }

    public function DeleteDataRuangan()
    {
        $kd_ruangan = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_ruangan', 'kd_ruangan', $kd_ruangan);
        redirect(site_url('Schedule/DataRuangan'));
    }

    //  Akhir Data Ruangan -------------------------------------------------------------------------------------------------------------



    //-----------------------------------------------Awal Data Jadwal-----------------------------------------------------------------//
    public function DataJadwal()
    {
        if ($this->uri->segment(4) == 'view') {
            $kd_jadwal = $this->uri->segment(3);
            $tampil = $this->MSudi->GetDataWhere('tbl_jadwal', 'kd_jadwal', $kd_jadwal)->row();
            $data['DataAddHari'] = $this->MSudi->GetData('tbl_hari');
            $data['DataAddMatkul'] = $this->MSudi->GetData('tbl_matakuliah');
            $data['DataAddDosen'] = $this->MSudi->GetData('tbl_dosen');
            $data['DataAddJurusan'] = $this->MSudi->GetData('tbl_jurusan');
            $data['DataAddRuangan'] = $this->MSudi->GetData('tbl_ruangan');
            $data['detail']['kd_jadwal'] = $tampil->kd_jadwal;
            $data['detail']['tahun_akademik'] = $tampil->tahun_akademik;
            $data['detail']['kd_hari'] = $tampil->kd_hari;
            $data['detail']['kd_matkul'] = $tampil->kd_matkul;
            $data['detail']['kd_dosen'] = $tampil->kd_dosen;
            $data['detail']['kd_jurusan'] = $tampil->kd_jurusan;
            $data['detail']['kd_ruangan'] = $tampil->kd_ruangan;
            $data['content'] = 'VFormUpdateJadwal';
        } else {
            $data['DataJadwal'] = $this->MSudi->GetRelation();
            $data['content'] = 'VJadwal';
        }

        $this->load->view('VBackend', $data);
    }

    public function VFormAddJadwal()
    {
        $data['content'] = 'VFormAddJadwal';
        $data['DataHari'] = $this->MSudi->GetData('tbl_hari');
        $data['DataMatkul'] = $this->MSudi->GetData('tbl_matakuliah');
        $data['DataDosen'] = $this->MSudi->GetData('tbl_dosen');
        $data['DataJurusan'] = $this->MSudi->GetData('tbl_jurusan');
        $data['DataRuangan'] = $this->MSudi->GetData('tbl_ruangan');
        $this->load->view('VBackend', $data);
    }

    public function AddDataJadwal()
    {
        $add['kd_jadwal'] = $this->input->post('kd_jadwal');
        $add['tahun_akademik'] = $this->input->post('tahun_akademik');
        $add['kd_hari'] = $this->input->post('kd_hari');
        $add['kd_matkul'] = $this->input->post('kd_matkul');
        $add['kd_dosen'] = $this->input->post('kd_dosen');
        $add['kd_jurusan'] = $this->input->post('kd_jurusan');
        $add['kd_ruangan'] = $this->input->post('kd_ruangan');
        $this->MSudi->AddData('tbl_jadwal', $add);
        redirect(site_url('Schedule/DataJadwal'));
    }

    public function UpdateDataJadwal()
    {
        $kd_jadwal = $this->input->post('kd_jadwal');
        $update['kd_hari'] = $this->input->post('kd_hari');
        $update['kd_matkul'] = $this->input->post('kd_matkul');
        $update['kd_dosen'] = $this->input->post('kd_dosen');
        $update['kd_jurusan'] = $this->input->post('kd_jurusan');
        $update['kd_ruangan'] = $this->input->post('kd_ruangan');
        $this->MSudi->UpdateData('tbl_jadwal', 'kd_jadwal', $kd_jadwal, $update);
        redirect(site_url('Schedule/DataJadwal'));
    }

    public function DeleteDataJadwal()
    {
        $kd_jadwal = $this->uri->segment('3');
        $this->MSudi->DeleteData('tbl_jadwal', 'kd_jadwal', $kd_jadwal);
        redirect(site_url('Schedule/DataJadwal'));
    }

//-----------------------------------------------Akhir Data Jadwal-----------------------------------------------------------------//
    public function Logout()
    {
        $this->load->library('session');
        $this->session->unset_userdata('Login');
        redirect(site_url('Jadwal'));
    }
}
