<?php

defined('BASEPATH') or exit('No direct script access allowed');

class MSudi extends CI_Model
{
    public function AddData($tabel, $data = array())
    {
        $this->db->insert($tabel, $data);
    }

    public function UpdateData($tabel, $fieldid, $fieldvalue, $data = array())
    {
        $this->db->where($fieldid, $fieldvalue)->update($tabel, $data);
    }

    public function DeleteData($tabel, $fieldid, $fieldvalue)
    {
        $this->db->where($fieldid, $fieldvalue)->delete($tabel);
    }

    public function GetData($tabel)
    {
        $query = $this->db->get($tabel);

        return $query->result();
    }

    public function GetDataWhere($tabel, $id, $nilai)
    {
        $this->db->where($id, $nilai);
        $query = $this->db->get($tabel);

        return $query;
    }

    public function GetRelation()
    {
        $this->db->select('*');
        $this->db->from('tbl_jadwal');
        $this->db->join('tbl_matakuliah', 'tbl_jadwal.kd_matkul=tbl_matakuliah.kd_matkul');
        $this->db->join('tbl_dosen', 'tbl_jadwal.kd_dosen=tbl_dosen.kd_dosen');
        $this->db->join('tbl_jurusan', 'tbl_jadwal.kd_jurusan=tbl_jurusan.kd_jurusan');
        $this->db->join('tbl_ruangan', 'tbl_jadwal.kd_ruangan=tbl_ruangan.kd_ruangan');
        $this->db->join('tbl_hari', 'tbl_jadwal.kd_hari=tbl_hari.kd_hari');
        $this->db->order_by('tbl_jadwal.kd_jadwal', 'asc');
        $query = $this->db->get();

        return $query->result();
    }

    public function GetJadwal()
    {
        $hari = date('D');

        switch ($hari) {
            case 'Sun':
                $hari_ini = 'Minggu';
            break;

            case 'Mon':
                $hari_ini = 'Senin';
            break;

            case 'Tue':
                $hari_ini = 'Selasa';
            break;

            case 'Wed':
                $hari_ini = 'Rabu';
            break;

            case 'Thu':
                $hari_ini = 'Kamis';
            break;

            case 'Fri':
                $hari_ini = 'Jumat';
            break;

            case 'Sat':
                $hari_ini = 'Sabtu';
            break;

            default:
                $hari_ini = 'Tidak di ketahui';
            break;
        }

        $this->db->select('*');
        $this->db->from('tbl_jadwal');
        $this->db->join('tbl_matakuliah', 'tbl_jadwal.kd_matkul=tbl_matakuliah.kd_matkul');
        $this->db->join('tbl_dosen', 'tbl_jadwal.kd_dosen=tbl_dosen.kd_dosen');
        $this->db->join('tbl_jurusan', 'tbl_jadwal.kd_jurusan=tbl_jurusan.kd_jurusan');
        $this->db->join('tbl_ruangan', 'tbl_jadwal.kd_ruangan=tbl_ruangan.kd_ruangan');
        $this->db->join('tbl_hari', 'tbl_jadwal.kd_hari=tbl_hari.kd_hari');
        $this->db->where('tbl_hari.nama_hari', $hari_ini);
        $this->db->order_by('tbl_jadwal.kd_jadwal', 'asc');
        $query = $this->db->get();

        return $query->result();
    }
}
