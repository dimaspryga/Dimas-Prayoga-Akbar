<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Update Data Mata Kuliah</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/UpdateDataMatkul'); ?>" method="post" class="form-horizontal">
		<div class="box-body">

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Nama Mata Kuliah</label>

				<div class="col-sm-10">
					<input type="hidden" name="kd_matkul" value="<?php echo $detail['kd_matkul']; ?>">
					<input type="text" name="nama_matkul" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Matakuliah..." value="<?php echo $detail['nama_matkul']; ?>">
				</div>
			</div>

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Waktu</label>

				<div class="col-sm-10">
					<input type="text" name="waktu" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Matakuliah..." value="<?php echo $detail['waktu']; ?>">
				</div>
			</div>

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Semester</label>

				<div class="col-sm-10">
					<input type="text" name="semester" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Matakuliah..." value="<?php echo $detail['semester']; ?>">
				</div>
			</div>
		
													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Update Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>
