<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Update Data Dosen</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/UpdateDataDosen'); ?>" method="post" class="form-horizontal">
		<div class="box-body">			

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Nama Dosen</label>

				<div class="col-sm-10">
					<input type="hidden" name="kd_dosen" value="<?php echo $detail['kd_dosen']; ?>">
					<input type="text" name="nama_dosen" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Dosen..."  value="<?php echo $detail['nama_dosen']; ?>">
				</div>
			</div>
													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Update Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>
