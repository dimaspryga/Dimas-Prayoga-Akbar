<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Mata Kuliah</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
				<tr>
					<td colspan="4">
						<a href="<?php echo site_url('Schedule/VFormAddMatkul'); ?>">Add</a>
					</td>
				</tr>
				<tr>
					<th>Kode Matkul</th>
					<th>Nama Mata Kuliah</th>
					<th>Waktu</th>
					<th>Semester</th>
          <th>Tools</th>
				</tr>
					<?php
                    if (!empty($DataMatkul)) {
                        foreach ($DataMatkul as $ReadDS) {
                            ?>

							<tr>
								<td><?php echo $ReadDS->kd_matkul; ?></td>
								<td><?php echo $ReadDS->nama_matkul; ?></td>
								<td><?php echo $ReadDS->waktu; ?></td>
								<td><?php echo $ReadDS->semester; ?></td>
								<td>
									<a href="<?php echo site_url('Schedule/DataMatkul/'.$ReadDS->kd_matkul.'/view'); ?>">Update</a>
									<a href="<?php echo site_url('Schedule/DeleteDataMatkul/'.$ReadDS->kd_matkul); ?>">Delete</a>
								</td>
							</tr>

					<?php
                        }
                    }
                    ?>
				
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>



</body>

</html>
