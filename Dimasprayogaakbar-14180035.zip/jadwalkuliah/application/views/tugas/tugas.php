<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Web Pertamaku</title>
    <link rel="stylesheet" href="style1.css">
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="bootstrap/icon/font/css/open-iconic-foundation.css">
</head>

<body>
    <table border="1" cellspacing="0" cellpadding="1">
        <!-- Menu Atas 1 -->
        <div id="menu-atas">

            <tr>
                <td colspan="5" class="navbar-top">
                    <a href="#" class="btn btn-link navbar-brand fi fi-grid-three-up"> MY TRIP HOLIDAY</a> |
                    <span> Belum Punya akun? </span><a href="#" class="btn-link">DAFTAR</a>
                    <a href="#" class="btn btn-outline-dark fi fi-account-login my-2 my-sm-0" style="float:right"> Masuk</a>
                </td>
            </tr>

        </div>
        <!-- Batas Akhir Menu Atas 1 -->


        <!-- Gambar Atas 1 -->
        <div id="gambar-atas">

            <tr>
                <td colspan="5">
                    <div id="GeserAja" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#GeserAja" data-slide-to="0" class="active"></li>
                            <li data-target="#GeserAja" data-slide-to="1"></li>
                            <li data-target="#GeserAja" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">

                            <div class="carousel-item active">
                                <img class="d-block w-100 panel-body img-fluid" src="img/41.jpg" alt="First slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100 panel-body img-fluid" src="img/42.jpg" alt="Second slide">
                            </div>
                            <div class="carousel-item">
                                <img class="d-block w-100 panel-body img-fluid" src="img/43.jpg" alt="Third slide">
                            </div>

                            <a class="carousel-control-prev" href="#GeserAja" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>

                            <a class="carousel-control-next" href="#GeserAja" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </td>
            </tr>

        </div>
        <!-- Batas Akhir Gambar Atas 1 -->

        <!-- Menu Atas 2 -->
        <div>
            <tr class="menu-atas2">
                <td colspan="5">
                    <a href="#" class="btn btn-link fi fi-home"> HOME</a>
                    <a href="#" class="btn btn-link fi fi-camera-slr"> TRIP</a>
                    <a href="#" class="btn btn-link fi fi-people"> HOTEL</a>
                    <a href="#" class="btn btn-link fi fi-pin"> DESTINATION</a>
                </td>
            </tr>
        </div>
        <!-- Batas Akhir Menu Atas 2 -->


        <!-- Gambar Atas -->
        <div>
            <tr>

                <!-- Kiri 1 -->
                <td rowspan="3" class="size-kanan-kiri text-white navbar-top">
                    <ul>
                        <li class="font-weight-bold">Travel List : </li>
                        <li><a href="#">Danau Toba</a></li>
                        <li><a href="#">Anambas</a></li>
                        <li><a href="#">Pulau Peucang</a></li>
                        <li><a href="#">Kawah Putih</a></li>
                        <li><a href="#">Pulau Seribu</a></li>
                        <li><a href="#">Gereja Ayam</a></li>
                        <li><a href="#">Pantai Siung</a></li>
                        <li><a href="#">Lombok</a></li>
                        <li><a href="#">Kawah Ijen</a></li>
                        <li><a href="#">Pulau Derawan</a></li>
                        <li><a href="#">Nusa Dua</a></li>
                        <li><a href="#">Gn. Rinjani</a></li>
                        <li><a href="#">Gn. Pangrango</a></li>
                        <li><a href="#">Pantai Losari</a></li>
                        <li><a href="#">Wakatobi</a></li>
                        <li><a href="#">Pantai Ora</a></li>
                        <li><a href="#">Raja Ampat</a></li>
                        <li><a href="#">Danau Sentani</a></li>
                        <li><a href="#">Pantai Sumurtiga</a></li>
                        <li><a href="#">Ngarai Sianok</a></li>
                        <li><a href="#">Sungai Kampar</a></li>
                        <li><a href="#">Candi Borobudur</a></li>
                        <li><a href="#">Candi Prambanan</a></li>
                        <li><a href="#">Pelabuhan Ratu</a></li>
                        <li><a href="#">Karimun Jawa</a></li>
                        <li><a href="#">Tugu Khatulistiwa</a></li>
                        <li><a href="#">Jembatan Barito</a></li>
                        <li><a href="#">Gili Trawangan</a></li>
                        <li><a href="#">Halmahera</a></li>
                        <li><a href="#">Kota Tua</a></li>
                        <li><a href="#">Tugu Kujang</a></li>
                        <li><a href="#">Kebun Raya</a></li>
                    </ul>
                </td>
                <!-- Batas Kiri 1 -->

                <!-- Tengah 1 -->
                <td colspan="3" class="navbar-margin">

                    <p>
                        <img src="img/55.jpg" alt="" class="img img-thumbnail img-fluid" width="300px" style="float:left;">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Quam ut tempore eaque quasi perferendis obcaecati ratione eveniet cumque assumenda.
                        Dolorum rerum illo hic ab pariatur fugit in, libero autem nihil?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Quam ut tempore eaque quasi perferendis obcaecati ratione eveniet cumque assumenda.
                        Dolorum rerum illo hic ab pariatur fugit in, libero autem nihil?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Quam ut tempore eaque quasi perferendis obcaecati ratione eveniet cumque assumenda.
                        Dolorum rerum illo hic ab pariatur fugit in, libero autem nihil?
                        Lorem ipsum dolor sit amet consectetur adipisicing elit.
                        Quam ut tempore eaque quasi perferendis obcaecati ratione eveniet cumque assumenda.
                        <a href="#">Selengkapnya.....</a>
                    </p>
                </td>
                <!-- Batas Tengah 1 -->


                <!-- Kanan 1 -->
                <td rowspan="3" class="size-kanan-kiri text-white navbar-top">
                    <ul>
                        <li class="font-weight-bold">Hotel List : </li>
                        <li><a href="#">MaxOneHotels</a></li>
                        <li><a href="#">Maharadja</a></li>
                        <li><a href="#">Kyriad Metro</a></li>
                        <li><a href="#">Arosa</a></li>
                        <li><a href="#">Cabin</a></li>
                        <li><a href="#">Grand G7</a></li>
                        <li><a href="#">Twin Plaza</a></li>
                        <li><a href="#">FaveHotel</a></li>
                        <li><a href="#">Cordela Norwood</a></li>
                        <li><a href="#">Samala</a></li>
                        <li><a href="#">Cordela Senen</a></li>
                        <li><a href="#">Arimbi Pejaten</a></li>
                        <li><a href="#">D'primaHotel</a></li>
                        <li><a href="#">Red Planet</a></li>
                        <li><a href="#">Fiducia</a></li>
                        <li><a href="#">N1 Hotel</a></li>
                        <li><a href="#">Dequr</a></li>
                        <li><a href="#">Maxim</a></li>
                        <li><a href="#">Cordex</a></li>
                        <li><a href="#">Caravan</a></li>
                        <li><a href="#">Royal Juanda</a></li>
                        <li><a href="#">Diradja</a></li>
                        <li><a href="#">Tugu Asri</a></li>
                        <li><a href="#">Maple Hotel</a></li>
                        <li><a href="#">Shakti</a></li>
                        <li><a href="#">Grand Menteng</a></li>
                        <li><a href="#">Juno Hotel</a></li>
                        <li><a href="#">Hotel Indonesia</a></li>
                        <li><a href="#">Home 889</a></li>
                        <li><a href="#">Neo Hotel</a></li>
                        <li><a href="#">Yello Hotel</a></li>
                        <li><a href="#">Rivoli Hotel</a></li>
                    </ul>
                </td>
                <!-- Batas Kanan 1 -->
            </tr>
        </div>
        <!-- Batas Akhir Gambar Atas -->


        <!-- Gambar Tengah -->
        <div id="gambar-tengah">
            <tr>

                <td colspan="3" align="center" class="navbar-top">
                    <h2>Foodie</h2>
                    <img src="img/56.jpg" class="img img-thumbnail col col-md-3">
                    <img src="img/59.jpg" class="img img-thumbnail col col-md-3">
                    <img src="img/60.jpg" class="img img-thumbnail col col-md-3">
                </td>

            </tr>
        </div>
        <!-- Batas Akhir Gambar Tengah -->


        <!-- Gambar Bawah -->
        <div id=" gambar-bawah">
            <tr>
                <td>
                    <ul class="kiri2">
                        <li class="font-weight-bold">Foods List : </li>
                        <li><a href="#">Nasi Goreng</a></li>
                        <li><a href="#">Udang Saus Padang</a></li>
                        <li><a href="#">Kue Coklat</a></li>
                        <li><a href="#">Roti Lapis</a></li>
                    </ul>
                </td>

                <td align="center">
                    <img src="img/51.jpg" class="img img-thumbnail col-lg-5 img-bottom"><br>
                    <img src="img/52.jpg" class="img img-thumbnail col-lg-5 img-bottom">
                </td>

                <td>
                    <ul class="kanan2">
                        <li class="font-weight-bold">Drinks List : </li>
                        <li><a href="#">Teh Tarik</a></li>
                        <li><a href="#">Cappuchino</a></li>
                        <li><a href="#">Teh Hijau</a></li>
                        <li><a href="#">Aneka Jus</a></li>
                    </ul>
                </td>
            </tr>
        </div>
        <!-- Batas Akhir Gambar Bawah -->

        <!-- Footer -->
        <div>
            <tr>
                <td colspan="5" class="navbar-bottom">
                    <p class="footer text-center">© 2019 Copyright : Bayu Iskandar
                        <br><span class="fi fi-person"> Contact Me : </span><a href="#" class="btn-link"> biskandar128@gmail.com</a></p>
                </td>
            </tr>
        </div>
        <!-- Batas Akhir Footer -->

    </table>

    <script src="bootstrap/js/jquery-3.4.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>


</body>

</html>