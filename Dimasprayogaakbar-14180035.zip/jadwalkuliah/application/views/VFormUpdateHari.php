<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Update Data Hari</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/UpdateDataHari'); ?>" method="post" class="form-horizontal">
		<div class="box-body">			

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Nama Hari</label>

				<div class="col-sm-10">
					<input type="hidden" name="kd_hari" value="<?php echo $detail['kd_hari']; ?>">
					<input type="text" name="nama_hari" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Hari..."  value="<?php echo $detail['nama_hari']; ?>">
				</div>
			</div>
													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Update Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>
