<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Jadwal</h3>              

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>
					<td colspan="8">
						<a href="<?php echo site_url('Schedule/VFormAddJadwal'); ?>">Add</a>
					</td>
				</tr>
				<tr>
					<th>Hari</th>
					<th>Nama Matkul</th>
					<th>Nama Kelas</th>
					<th>Nama Dosen</th>
					<th>Waktu Matkul</th>
					<th>Jurusan</th>
					<th>Semester</th>
          <th>Tools</th>
				</tr>
				<?php
                if (!empty($DataJadwal)) {
                    foreach ($DataJadwal as $ReadDS) {
                        ?>

						<tr>
							<td><?php echo $ReadDS->nama_hari; ?></td>
							<td><?php echo $ReadDS->nama_matkul; ?></td>
							<td><?php echo $ReadDS->nama_ruangan; ?></td>
							<td><?php echo $ReadDS->nama_dosen; ?></td>
							<td><?php echo $ReadDS->waktu; ?></td>
							<td><?php echo $ReadDS->nama_jurusan; ?></td>
							<td><?php echo $ReadDS->semester; ?></td>
							<td>
								<a href="<?php echo site_url('Schedule/DataJadwal/'.$ReadDS->kd_jadwal.'/view'); ?>">Update</a>
								<a href="<?php echo site_url('Schedule/DeleteDataJadwal/'.$ReadDS->kd_jadwal); ?>">Delete</a>
							</td>
						</tr>

				<?php
                    }
                }
                ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
