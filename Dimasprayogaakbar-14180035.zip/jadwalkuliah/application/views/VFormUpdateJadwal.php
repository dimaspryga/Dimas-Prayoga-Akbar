<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Update Data Jadwal</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/UpdateDataJadwal'); ?>" method="post" class="form-horizontal">
		<div class="box-body">

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Tahun Akademik</label>

				<div class="col-sm-10">
					<input type="hidden" name="kd_jadwal" value="<?php echo $detail['kd_jadwal']; ?>">
					<input type="text" name="tahun_akademik" class="form-control" id="inputPassword3" placeholder="Masukkan Tahun Akademik..." value="<?php echo $detail['tahun_akademik']; ?>">
				</div>
			</div>

			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Matkul</label>

				<div class="col-sm-10">
					<select name="kd_matkul" class="form-control">

					<option value="<?php echo $detail['kd_matkul']; ?>">Data Sebelum di ubah : <?php echo $detail['kd_matkul']; ?></option>

					<option>--Pilih Kode Matakuliah--</option>

					<?php foreach ($DataAddMatkul as $ReadMtkl) : ?>
					

						<option value="<?= $ReadMtkl->kd_matkul; ?>">
						<?= $ReadMtkl->kd_matkul; ?> || <?= $ReadMtkl->nama_matkul; ?> || Semester <?= $ReadMtkl->semester; ?> </option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>


			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Kelas</label>

				<div class="col-sm-10">
					<select name="kd_ruangan" class="form-control">

					<option value="<?php echo $detail['kd_ruangan']; ?>">Data Sebelum di ubah : <?php echo $detail['kd_ruangan']; ?></option>

						<option>--Pilih Kode Kelas--</option>

					<?php foreach ($DataAddRuangan as $ReadKls) : ?>
					
						<option value="<?= $ReadKls->kd_ruangan; ?>">
						<?= $ReadKls->kd_ruangan; ?> || Ruangan <?= $ReadKls->nama_ruangan; ?> </option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>



			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Dosen</label>

				<div class="col-sm-10">
					<select name="kd_dosen" class="form-control">

					<option value="<?php echo $detail['kd_dosen']; ?>">Data Sebelum di ubah : <?php echo $detail['kd_dosen']; ?></option>

					<option>--Pilih NID--</option>

					<?php foreach ($DataAddDosen as $ReadNid) : ?>
					

						<option value="<?= $ReadNid->kd_dosen; ?>">
						<?= $ReadNid->kd_dosen; ?> || <?= $ReadNid->nama_dosen; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>


			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Hari</label>

				<div class="col-sm-10">
					<select name="kd_hari" class="form-control">

					<option value="<?php echo $detail['kd_hari']; ?>">Data Sebelum di ubah : <?php echo $detail['kd_hari']; ?></option>

					<option>--Pilih NID--</option>

					<?php foreach ($DataAddHari as $ReadHari) : ?>
					

						<option value="<?= $ReadHari->kd_hari; ?>">
						<?= $ReadHari->kd_hari; ?> ||  <?= $ReadHari->nama_hari; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>

			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Jurusan</label>

				<div class="col-sm-10">
					<select name="kd_jurusan" class="form-control">

					<option value="<?php echo $detail['kd_jurusan']; ?>">Data Sebelum di ubah : <?php echo $detail['kd_jurusan']; ?></option>

					<option>--Pilih NID--</option>

					<?php foreach ($DataAddJurusan as $ReadJrs) : ?>
					

						<option value="<?= $ReadJrs->kd_jurusan; ?>">
						<?= $ReadJrs->kd_jurusan; ?> || <?= $ReadJrs->nama_jurusan; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>


													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Update Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>
