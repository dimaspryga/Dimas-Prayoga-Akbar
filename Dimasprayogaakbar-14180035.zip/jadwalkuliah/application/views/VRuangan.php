<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Ruangan</h3>

              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tr>
					<td colspan="4">
						<a href="<?php echo site_url('Schedule/VFormAddRuangan'); ?>">Add</a>
					</td>
				</tr>
				<tr>
					<th>Kode Ruangan</th>
					<th>Nama Ruangan</th>
          <th>Tools</th>
				</tr>
							
				
				<?php
                if (!empty($DataRuangan)) {
                    foreach ($DataRuangan as $ReadDS) {
                        ?>

						<tr>
							<td><?php echo $ReadDS->kd_ruangan; ?></td>
							<td><?php echo $ReadDS->nama_ruangan; ?></td>
							<td>
								<a href="<?php echo site_url('Schedule/DataKelas/'.$ReadDS->kd_ruangan.'/view'); ?>">Update</a>
								<a href="<?php echo site_url('Schedule/DeleteDataRuangan/'.$ReadDS->kd_ruangan); ?>">Delete</a>
							</td>
						</tr>

				<?php
                    }
                }
                ?>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
