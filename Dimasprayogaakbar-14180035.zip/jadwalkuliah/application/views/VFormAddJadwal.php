
<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Tambah Data Jadwal</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/AddDataJadwal'); ?>" method="post" class="form-horizontal">
		<div class="box-body">

			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Jadwal</label>

				<div class="col-sm-10">
					<input type="text" name="kd_jadwal" class="form-control" id="inputEmail3" placeholder="Masukkan Kode Jadwal...">
				</div>
			</div>

			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Tahun Akademik</label>

				<div class="col-sm-10">
					<input type="text" name="tahun_akademik" class="form-control" id="inputPassword3" placeholder="Masukkan Tahun Akademik...">
				</div>
			</div>

			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Matkul</label>

				<div class="col-sm-10">
					<select name="kd_matkul" class="form-control">

					<option>--Pilih Kode Matakuliah--</option>

					<?php foreach ($DataMatkul as $ReadMtkl) : ?>
					

						<option value="<?= $ReadMtkl->kd_matkul; ?>">
						<?= $ReadMtkl->kd_matkul; ?> || <?= $ReadMtkl->nama_matkul; ?> || Semester <?= $ReadMtkl->semester; ?> </option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>


			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Jurusan</label>

				<div class="col-sm-10">
					<select name="kd_jurusan" class="form-control">

					<option>--Pilih Kode Jurusan--</option>

					<?php foreach ($DataJurusan as $ReadJrs) : ?>
					

						<option value="<?= $ReadJrs->kd_jurusan; ?>">
						<?= $ReadJrs->kd_jurusan; ?> || <?= $ReadJrs->nama_jurusan; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>
			

			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Kode Ruangan</label>

				<div class="col-sm-10">
					<select name="kd_ruangan" class="form-control">

						<option>--Pilih Kode Ruangan--</option>

					<?php foreach ($DataRuangan as $ReadKls) : ?>
					
						<option value="<?= $ReadKls->kd_ruangan; ?>">
						<?= $ReadKls->kd_ruangan; ?> || <?= $ReadKls->nama_ruangan; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>



			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">NID</label>

				<div class="col-sm-10">
					<select name="kd_dosen" class="form-control">

					<option>--Pilih NID--</option>

					<?php foreach ($DataDosen as $ReadNid) : ?>	
					

						<option value="<?= $ReadNid->kd_dosen; ?>">
						<?= $ReadNid->kd_dosen; ?> || <?= $ReadNid->nama_dosen; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>


			<div class="form-group">
				<label for="inputEmail3" class="col-sm-2 control-label">Hari</label>

				<div class="col-sm-10">
					<select name="kd_hari" class="form-control">

					<option>--Pilih Hari--</option>

					<?php foreach ($DataHari as $ReadHari) : ?>	
					

						<option value="<?= $ReadHari->kd_hari; ?>">
						<?= $ReadHari->kd_hari; ?> ||  <?= $ReadHari->nama_hari; ?></option>

					<?php endforeach; ?>
						

					</select>

				</div>
			</div>



													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Masukkan Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>
