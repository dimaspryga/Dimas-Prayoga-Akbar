<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Update Data Ruangan</h3>
	</div>
	<!-- /.box-header -->
	<!-- form start -->
	<form action="<?php echo site_url('Schedule/UpdateDataRuangan'); ?>" method="post" class="form-horizontal">
		<div class="box-body">


			<div class="form-group">
				<label for="inputPassword3" class="col-sm-2 control-label">Nama Ruangan</label>

				<div class="col-sm-10">
					<input type="hidden" name="kd_ruangan" value="<?php echo $detail['kd_ruangan']; ?>">
					<input type="text" name="nama_ruangan" class="form-control" id="inputPassword3" placeholder="Masukkan Nama Ruangan..."  value="<?php echo $detail['nama_ruangan']; ?>">
				</div>
			</div>
													
		</div>
		<!-- /.box-body -->
		<div class="box-footer">
			<button type="submit" name="simpan" class="btn btn-info pull-right">Update Data</button>
		</div>
		<!-- /.box-footer -->
	</form>
</div>



